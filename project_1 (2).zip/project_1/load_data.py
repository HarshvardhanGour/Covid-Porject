import pandas as pd

def load_dataframe(path):
    dataframe=pd.read_csv(path)
    return dataframe