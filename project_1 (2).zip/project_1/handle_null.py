import numpy as np

def handle_null_val(dataframe):
    for col in list(dataframe.columns):
        if dataframe[col].dtypes=="int64":
            dataframe[col]=dataframe[col].replace(np.nan,0)
            dataframe[col]=dataframe[col].replace(0,np.median(dataframe[col]))
        elif dataframe[col].dtypes=="float64":
            dataframe[col]=dataframe[col].replace(np.nan,np.mean(dataframe[col]))
        elif dataframe[col].dtypes=="object":
            dataframe[col]=dataframe[col].replace(np.nan,dataframe[col].mode()[0])
        else:
            pass
    return dataframe