from sklearn.decomposition import PCA
import pandas as pd
pc=PCA(n_components=5)

def apply_pca(dataframe):
    array_data=pc.fit_transform(dataframe)
    col=["col_A","col_B","col_C","col_D","col_E"]
    df=pd.DataFrame(array_data,columns=col)
    return df