from sklearn.preprocessing import LabelEncoder

le=LabelEncoder()

def encode_dataframe(dataframe):
    for col in list(dataframe.columns):
        if dataframe[col].dtypes=="object":
            dataframe[col]=le.fit_transform(dataframe[col])
            
    return dataframe