from sklearn.preprocessing import StandardScaler
import pandas as pd

sc=StandardScaler()

def scale_df(dataframe):
    array_data=sc.fit_transform(dataframe)
    df=pd.DataFrame(array_data,columns=dataframe.columns)
    return df