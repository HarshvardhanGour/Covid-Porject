from sklearn.preprocessing import power_transform
import pandas as pd

def rem_skew(dataframe):
    array_data=power_transform(dataframe,method="yeo-johnson")
    dataframe=pd.DataFrame(array_data,columns=dataframe.columns)
    return dataframe